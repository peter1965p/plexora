import { d as defineEventHandler, a as getRouterParam, c as createError } from '../../../nitro/nitro.mjs';
import { GetCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const _id__get = defineEventHandler(async (event) => {
  const formId = getRouterParam(event, "id");
  const client = getDynamoClient();
  const { Item } = await client.send(new GetCommand({
    TableName: "plexora-forms",
    Key: { formId }
  }));
  if (!Item) throw createError({ statusCode: 404, message: "Form not found" });
  return { form: Item };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
