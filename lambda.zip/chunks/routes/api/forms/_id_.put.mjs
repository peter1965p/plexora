import { d as defineEventHandler, a as getRouterParam, r as readBody } from '../../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const _id__put = defineEventHandler(async (event) => {
  const formId = getRouterParam(event, "id");
  const body = await readBody(event);
  const client = getDynamoClient();
  await client.send(new PutCommand({
    TableName: "plexora-forms",
    Item: { ...body, formId, updated: (/* @__PURE__ */ new Date()).toISOString() }
  }));
  return { success: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
