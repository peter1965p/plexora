import { d as defineEventHandler, a as getRouterParam } from '../../../../nitro/nitro.mjs';
import { QueryCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const submissions_get = defineEventHandler(async (event) => {
  const formId = getRouterParam(event, "id");
  const client = getDynamoClient();
  const { Items } = await client.send(new QueryCommand({
    TableName: "plexora-submissions",
    IndexName: "form-index",
    KeyConditionExpression: "formId = :fid",
    ExpressionAttributeValues: { ":fid": formId }
  }));
  return { submissions: Items || [] };
});

export { submissions_get as default };
//# sourceMappingURL=submissions.get.mjs.map
