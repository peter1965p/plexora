import { d as defineEventHandler, a as getRouterParam, r as readBody, c as createError } from '../../../../nitro/nitro.mjs';
import { GetCommand, PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const submit_post = defineEventHandler(async (event) => {
  const formId = getRouterParam(event, "id");
  const body = await readBody(event);
  const client = getDynamoClient();
  const { Item: form } = await client.send(new GetCommand({
    TableName: "plexora-forms",
    Key: { formId }
  }));
  if (!form) throw createError({ statusCode: 404, message: "Form not found" });
  await client.send(new PutCommand({
    TableName: "plexora-submissions",
    Item: {
      submissionId: randomUUID(),
      formId,
      formTitle: form.title,
      data: body.data || {},
      created: (/* @__PURE__ */ new Date()).toISOString()
    }
  }));
  return { success: true, message: form.successMsg };
});

export { submit_post as default };
//# sourceMappingURL=submit.post.mjs.map
