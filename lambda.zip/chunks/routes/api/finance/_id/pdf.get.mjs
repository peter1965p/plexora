import { d as defineEventHandler, a as getRouterParam, g as getQuery, c as createError, s as setHeader } from '../../../../nitro/nitro.mjs';
import { GetCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../../_/dynamodb.mjs';
import PDFDocument from 'pdfkit';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

async function generatePDF(invoice, branding) {
  return new Promise((resolve, reject) => {
    var _a;
    const doc = new PDFDocument({ margin: 50, size: "A4" });
    const chunks = [];
    doc.on("data", (chunk) => chunks.push(chunk));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);
    const brand = (branding == null ? void 0 : branding.brandName) || "Plexora";
    const accent = [124, 58, 237];
    doc.fontSize(28).fillColor(accent).font("Helvetica-Bold").text(brand, 50, 50);
    doc.fontSize(10).fillColor([150, 150, 150]).font("Helvetica").text((branding == null ? void 0 : branding.brandTagline) || "Business Platform", 50, 85);
    doc.fontSize(22).fillColor([30, 30, 30]).font("Helvetica-Bold").text("RECHNUNG", 350, 50, { align: "right", width: 200 });
    doc.fontSize(11).fillColor([80, 80, 80]).font("Helvetica").text(`Nr: ${invoice.number || ((_a = invoice.invoiceId) == null ? void 0 : _a.slice(0, 8).toUpperCase())}`, 350, 80, { align: "right", width: 200 }).text(`Datum: ${new Date(invoice.created || Date.now()).toLocaleDateString("de-DE")}`, 350, 96, { align: "right", width: 200 }).text(`F\xE4lligkeit: ${invoice.dueDate || "\u2013"}`, 350, 112, { align: "right", width: 200 });
    doc.moveTo(50, 140).lineTo(545, 140).strokeColor(accent).lineWidth(2).stroke();
    doc.fontSize(10).fillColor([120, 120, 120]).font("Helvetica").text("RECHNUNGSEMPF\xC4NGER", 50, 160);
    doc.fontSize(13).fillColor([20, 20, 20]).font("Helvetica-Bold").text(invoice.client || "\u2013", 50, 178);
    doc.rect(50, 240, 495, 28).fill([245, 245, 250]);
    doc.fontSize(10).fillColor([80, 80, 80]).font("Helvetica-Bold").text("BESCHREIBUNG", 60, 250).text("MENGE", 320, 250).text("EINZELPREIS", 390, 250).text("GESAMT", 470, 250);
    const items = invoice.items || [{ description: invoice.description || "Dienstleistung", qty: 1, price: invoice.amount }];
    let y = 290;
    items.forEach((item) => {
      const total = (item.qty || 1) * (item.price || invoice.amount || 0);
      doc.fontSize(11).fillColor([30, 30, 30]).font("Helvetica").text(item.description || "Dienstleistung", 60, y, { width: 250 }).text(String(item.qty || 1), 320, y).text(`\u20AC ${Number(item.price || invoice.amount).toLocaleString("de-DE")}`, 390, y).text(`\u20AC ${total.toLocaleString("de-DE")}`, 470, y);
      doc.moveTo(50, y + 22).lineTo(545, y + 22).strokeColor([230, 230, 230]).lineWidth(0.5).stroke();
      y += 30;
    });
    const netto = Number(invoice.amount) || 0;
    const mwst = Math.round(netto * 0.19 * 100) / 100;
    const brutto = netto + mwst;
    doc.moveTo(350, y + 10).lineTo(545, y + 10).strokeColor(accent).lineWidth(1).stroke();
    doc.fontSize(10).fillColor([80, 80, 80]).font("Helvetica").text("Nettobetrag:", 350, y + 20).text(`\u20AC ${netto.toLocaleString("de-DE")}`, 470, y + 20).text("MwSt. 19%:", 350, y + 36).text(`\u20AC ${mwst.toLocaleString("de-DE")}`, 470, y + 36);
    doc.rect(350, y + 54, 195, 28).fill(accent);
    doc.fontSize(12).fillColor([255, 255, 255]).font("Helvetica-Bold").text("GESAMT:", 360, y + 62).text(`\u20AC ${brutto.toLocaleString("de-DE")}`, 470, y + 62);
    doc.moveTo(50, 750).lineTo(545, 750).strokeColor([220, 220, 220]).lineWidth(0.5).stroke();
    doc.fontSize(9).fillColor([150, 150, 150]).font("Helvetica").text(`${brand} \u2014 Vielen Dank f\xFCr Ihr Vertrauen!`, 50, 760, { align: "center", width: 495 });
    doc.end();
  });
}
const pdf_get = defineEventHandler(async (event) => {
  const invoiceId = getRouterParam(event, "id");
  const userId = getQuery(event).userId || "demo-user";
  const dynamo = getDynamoClient();
  const scan = await dynamo.send(new GetCommand({
    TableName: "plexora-finance",
    Key: { userId, invoiceId }
  }));
  const invoice = scan.Item;
  if (!invoice) throw createError({ statusCode: 404, message: "Rechnung nicht gefunden" });
  let branding = { brandName: "Plexora", brandTagline: "Business Platform" };
  try {
    const bs = await dynamo.send(new GetCommand({
      TableName: "plexora-settings",
      Key: { settingId: "branding", scope: "global" }
    }));
    if (bs.Item) branding = bs.Item;
  } catch {
  }
  const pdfBuffer = await generatePDF(invoice, branding);
  setHeader(event, "Content-Type", "application/pdf");
  setHeader(event, "Content-Disposition", `attachment; filename="Rechnung-${invoice.number || (invoiceId == null ? void 0 : invoiceId.slice(0, 8))}.pdf"`);
  return pdfBuffer;
});

export { pdf_get as default };
//# sourceMappingURL=pdf.get.mjs.map
