import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const client = getDynamoClient();
  const campaign = {
    userId: body.userId || "demo-user",
    campaignId: randomUUID(),
    title: body.title,
    department: body.department,
    location: body.location,
    type: body.type || "fulltime",
    description: body.description,
    requirements: body.requirements,
    status: "active",
    created: (/* @__PURE__ */ new Date()).toISOString()
  };
  await client.send(new PutCommand({ TableName: "plexora-campaigns", Item: campaign }));
  return { success: true, campaign };
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
