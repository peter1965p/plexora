import { d as defineEventHandler, a as getRouterParam } from '../../../../../nitro/nitro.mjs';
import { ScanCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const applications_get = defineEventHandler(async (event) => {
  const campaignId = getRouterParam(event, "id");
  const client = getDynamoClient();
  const result = await client.send(new ScanCommand({
    TableName: "plexora-applications",
    FilterExpression: "campaignId = :id",
    ExpressionAttributeValues: { ":id": campaignId }
  }));
  return { applications: result.Items || [] };
});

export { applications_get as default };
//# sourceMappingURL=applications.get.mjs.map
