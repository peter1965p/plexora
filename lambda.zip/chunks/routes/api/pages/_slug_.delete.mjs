import { d as defineEventHandler, a as getRouterParam, c as createError } from '../../../nitro/nitro.mjs';
import { QueryCommand, DeleteCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const _slug__delete = defineEventHandler(async (event) => {
  const slug = getRouterParam(event, "slug");
  const client = getDynamoClient();
  const { Items } = await client.send(new QueryCommand({
    TableName: "plexora-pages",
    IndexName: "slug-index",
    KeyConditionExpression: "slug = :slug",
    ExpressionAttributeValues: { ":slug": slug }
  }));
  if (!(Items == null ? void 0 : Items.length)) throw createError({ statusCode: 404, message: "Page not found" });
  await client.send(new DeleteCommand({
    TableName: "plexora-pages",
    Key: { pageId: Items[0].pageId }
  }));
  return { success: true };
});

export { _slug__delete as default };
//# sourceMappingURL=_slug_.delete.mjs.map
