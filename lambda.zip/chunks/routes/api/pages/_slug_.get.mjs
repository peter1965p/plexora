import { d as defineEventHandler, a as getRouterParam, c as createError } from '../../../nitro/nitro.mjs';
import { QueryCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const _slug__get = defineEventHandler(async (event) => {
  const slug = getRouterParam(event, "slug");
  const client = getDynamoClient();
  const { Items } = await client.send(new QueryCommand({
    TableName: "plexora-pages",
    IndexName: "slug-index",
    KeyConditionExpression: "slug = :slug",
    ExpressionAttributeValues: { ":slug": slug }
  }));
  if (!(Items == null ? void 0 : Items.length)) throw createError({ statusCode: 404, message: "Page not found" });
  return { page: Items[0] };
});

export { _slug__get as default };
//# sourceMappingURL=_slug_.get.mjs.map
