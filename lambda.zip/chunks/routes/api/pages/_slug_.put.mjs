import { d as defineEventHandler, a as getRouterParam, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { QueryCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const _slug__put = defineEventHandler(async (event) => {
  var _a;
  const slug = getRouterParam(event, "slug");
  const body = await readBody(event);
  const client = getDynamoClient();
  const { Items } = await client.send(new QueryCommand({
    TableName: "plexora-pages",
    IndexName: "slug-index",
    KeyConditionExpression: "slug = :slug",
    ExpressionAttributeValues: { ":slug": slug }
  }));
  if (!(Items == null ? void 0 : Items.length)) throw createError({ statusCode: 404, message: "Page not found" });
  await client.send(new UpdateCommand({
    TableName: "plexora-pages",
    Key: { pageId: Items[0].pageId },
    UpdateExpression: "SET blocks = :b, title = :t, inNav = :n, navLabel = :l, #s = :s, updated = :u",
    ExpressionAttributeNames: { "#s": "status" },
    ExpressionAttributeValues: {
      ":b": body.blocks || [],
      ":t": body.title,
      ":n": (_a = body.inNav) != null ? _a : false,
      ":l": body.navLabel || body.title,
      ":s": body.status || "draft",
      ":u": (/* @__PURE__ */ new Date()).toISOString()
    }
  }));
  return { success: true };
});

export { _slug__put as default };
//# sourceMappingURL=_slug_.put.mjs.map
