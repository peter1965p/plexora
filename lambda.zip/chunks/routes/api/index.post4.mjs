import { d as defineEventHandler, r as readBody } from '../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const client = getDynamoClient();
  const invoice = {
    userId: body.userId || "demo-user",
    invoiceId: randomUUID(),
    number: "INV-" + Date.now(),
    client: body.client,
    clientEmail: body.clientEmail || "",
    description: body.description || "",
    amount: body.amount,
    status: body.status || "pending",
    dueDate: body.dueDate,
    mailSent: false,
    created: (/* @__PURE__ */ new Date()).toISOString()
  };
  await client.send(new PutCommand({ TableName: "plexora-finance", Item: invoice }));
  return { success: true, invoice };
});

export { index_post as default };
//# sourceMappingURL=index.post4.mjs.map
