import { d as defineEventHandler, a as getRouterParam, c as createError } from '../../../nitro/nitro.mjs';
import { ScanCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_get = defineEventHandler(async (event) => {
  var _a;
  const campaignId = getRouterParam(event, "id");
  const client = getDynamoClient();
  const result = await client.send(new ScanCommand({
    TableName: "plexora-campaigns",
    FilterExpression: "campaignId = :id",
    ExpressionAttributeValues: { ":id": campaignId }
  }));
  const campaign = (_a = result.Items) == null ? void 0 : _a[0];
  if (!campaign) throw createError({ statusCode: 404, message: "Stelle nicht gefunden" });
  return { campaign };
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
