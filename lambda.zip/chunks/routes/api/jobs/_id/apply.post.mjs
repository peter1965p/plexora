import { d as defineEventHandler, a as getRouterParam, r as readBody, c as createError, u as useRuntimeConfig } from '../../../../nitro/nitro.mjs';
import { ScanCommand, PutCommand, GetCommand } from '@aws-sdk/lib-dynamodb';
import { SendEmailCommand, SESClient } from '@aws-sdk/client-ses';
import { g as getDynamoClient } from '../../../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

function getSESClient() {
  const config = useRuntimeConfig();
  const accessKey = config.awsAccessKeyId.replace(/^"|"$/g, "");
  const secretKey = config.awsSecretAccessKey.replace(/^"|"$/g, "");
  return new SESClient({
    region: "eu-central-1",
    credentials: { accessKeyId: accessKey, secretAccessKey: secretKey }
  });
}
const apply_post = defineEventHandler(async (event) => {
  var _a, _b;
  const campaignId = getRouterParam(event, "id");
  const body = await readBody(event);
  const dynamo = getDynamoClient();
  const scan = await dynamo.send(new ScanCommand({
    TableName: "plexora-campaigns",
    FilterExpression: "campaignId = :id",
    ExpressionAttributeValues: { ":id": campaignId }
  }));
  const campaign = (_a = scan.Items) == null ? void 0 : _a[0];
  if (!campaign) throw createError({ statusCode: 404, message: "Stelle nicht gefunden" });
  const application = {
    campaignId,
    applicationId: randomUUID(),
    firstName: body.firstName,
    lastName: body.lastName,
    email: body.email,
    phone: body.phone || "",
    message: body.message || "",
    status: "new",
    created: (/* @__PURE__ */ new Date()).toISOString()
  };
  await dynamo.send(new PutCommand({ TableName: "plexora-applications", Item: application }));
  let brandName = "Plexora";
  try {
    const bs = await dynamo.send(new GetCommand({
      TableName: "plexora-settings",
      Key: { settingId: "branding", scope: "global" }
    }));
    if ((_b = bs.Item) == null ? void 0 : _b.brandName) brandName = bs.Item.brandName;
  } catch {
  }
  const ses = getSESClient();
  const fromEmail = "billing@paeffgen-it.de";
  try {
    await ses.send(new SendEmailCommand({
      Source: `${brandName} HR <${fromEmail}>`,
      Destination: { ToAddresses: [body.email] },
      Message: {
        Subject: { Data: `Bewerbungseingang: ${campaign.title}` },
        Body: {
          Html: {
            Data: `
              <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
                <h2 style="color:#7C3AED">${brandName}</h2>
                <p>Hallo ${body.firstName},</p>
                <p>vielen Dank f\xFCr Ihre Bewerbung als <strong>${campaign.title}</strong>.</p>
                <p>Wir haben Ihre Unterlagen erhalten und melden uns in K\xFCrze bei Ihnen.</p>
                <p style="color:#999;font-size:12px">\u2013 Das ${brandName} HR Team</p>
              </div>
            `
          }
        }
      }
    }));
  } catch (err) {
    console.log("Bewerber-Mail Fehler:", err.message);
  }
  return { success: true, applicationId: application.applicationId };
});

export { apply_post as default };
//# sourceMappingURL=apply.post.mjs.map
