import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { CloudWatchLogsClient, DescribeLogStreamsCommand, GetLogEventsCommand } from '@aws-sdk/client-cloudwatch-logs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const logs_get = defineEventHandler(async () => {
  const client = new CloudWatchLogsClient({ region: "eu-central-1" });
  try {
    const { logStreams } = await client.send(new DescribeLogStreamsCommand({
      logGroupName: "/aws/lambda/plexora-api",
      orderBy: "LastEventTime",
      descending: true,
      limit: 1
    }));
    if (!(logStreams == null ? void 0 : logStreams.length)) return { events: [] };
    const { events } = await client.send(new GetLogEventsCommand({
      logGroupName: "/aws/lambda/plexora-api",
      logStreamName: logStreams[0].logStreamName,
      limit: 50
    }));
    return {
      events: (events || []).map((e) => ({
        message: e.message,
        timestamp: e.timestamp
      }))
    };
  } catch {
    return { events: [] };
  }
});

export { logs_get as default };
//# sourceMappingURL=logs.get.mjs.map
