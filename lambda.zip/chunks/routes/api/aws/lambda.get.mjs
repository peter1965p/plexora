import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { LambdaClient, ListFunctionsCommand } from '@aws-sdk/client-lambda';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const lambda_get = defineEventHandler(async () => {
  const lambda = new LambdaClient({ region: "eu-central-1" });
  const { Functions } = await lambda.send(new ListFunctionsCommand({}));
  const functions = (Functions || []).map((f) => ({
    name: f.FunctionName,
    runtime: f.Runtime,
    memory: f.MemorySize,
    timeout: f.Timeout,
    lastModified: f.LastModified,
    codeSize: f.CodeSize,
    description: f.Description
  }));
  return { functions };
});

export { lambda_get as default };
//# sourceMappingURL=lambda.get.mjs.map
