import { d as defineEventHandler, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { S3Client, DeleteObjectCommand } from '@aws-sdk/client-s3';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const BUCKET = "plexora-files";
const s3Delete_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { key } = body;
  if (!key) {
    throw createError({ statusCode: 400, statusMessage: "key erforderlich" });
  }
  const client = new S3Client({ region: "eu-central-1" });
  await client.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: key }));
  return { success: true };
});

export { s3Delete_post as default };
//# sourceMappingURL=s3-delete.post.mjs.map
