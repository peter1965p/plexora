import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { DynamoDBClient, ListTablesCommand, DescribeTableCommand } from '@aws-sdk/client-dynamodb';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const dynamo_get = defineEventHandler(async () => {
  const client = new DynamoDBClient({ region: "eu-central-1" });
  const { TableNames } = await client.send(new ListTablesCommand({}));
  const tables = await Promise.all(
    (TableNames || []).map(async (name) => {
      var _a;
      const { Table } = await client.send(new DescribeTableCommand({ TableName: name }));
      return {
        name,
        itemCount: (Table == null ? void 0 : Table.ItemCount) || 0,
        sizeBytes: (Table == null ? void 0 : Table.TableSizeBytes) || 0,
        status: Table == null ? void 0 : Table.TableStatus,
        billingMode: ((_a = Table == null ? void 0 : Table.BillingModeSummary) == null ? void 0 : _a.BillingMode) || "PROVISIONED"
      };
    })
  );
  return { tables };
});

export { dynamo_get as default };
//# sourceMappingURL=dynamo.get.mjs.map
