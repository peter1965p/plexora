import { d as defineEventHandler, g as getQuery } from '../../../nitro/nitro.mjs';
import { S3Client, ListObjectsV2Command } from '@aws-sdk/client-s3';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const BUCKET = "plexora-files";
const s3_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const prefix = query.prefix || "";
  const client = new S3Client({ region: "eu-central-1" });
  const result = await client.send(new ListObjectsV2Command({
    Bucket: BUCKET,
    Prefix: prefix,
    Delimiter: "/"
  }));
  const folders = (result.CommonPrefixes || []).map((p) => ({
    name: (p.Prefix || "").slice(prefix.length).replace(/\/$/, ""),
    prefix: p.Prefix
  }));
  const files = (result.Contents || []).filter((o) => o.Key !== prefix).map((o) => ({
    key: o.Key,
    name: (o.Key || "").slice(prefix.length),
    size: o.Size || 0,
    lastModified: o.LastModified,
    url: `https://${BUCKET}.s3.eu-central-1.amazonaws.com/${o.Key}`
  }));
  return { bucket: BUCKET, prefix, folders, files };
});

export { s3_get as default };
//# sourceMappingURL=s3.get.mjs.map
