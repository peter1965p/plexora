import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { GetCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const DEFAULT_CONTENT = `# Allgemeine Gesch\xE4ftsbedingungen

*Hier k\xF6nnen Sie Ihre AGB als Markdown-Text einf\xFCgen.*

Nutzen Sie # f\xFCr \xDCberschriften und **fett** f\xFCr Hervorhebungen.
`;
const agb_get = defineEventHandler(async () => {
  const client = getDynamoClient();
  try {
    const result = await client.send(new GetCommand({
      TableName: "plexora-settings",
      Key: { settingId: "agb", scope: "global" }
    }));
    return { agb: result.Item || { content: DEFAULT_CONTENT, updated: null } };
  } catch {
    return { agb: { content: DEFAULT_CONTENT, updated: null } };
  }
});

export { agb_get as default };
//# sourceMappingURL=agb.get.mjs.map
