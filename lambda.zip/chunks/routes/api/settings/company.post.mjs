import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const company_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const client = getDynamoClient();
  await client.send(new PutCommand({
    TableName: "plexora-settings",
    Item: {
      settingId: "company",
      scope: "global",
      legalName: body.legalName || "",
      representedBy: body.representedBy || "",
      street: body.street || "",
      zipCity: body.zipCity || "",
      country: body.country || "Deutschland",
      email: body.email || "",
      phone: body.phone || "",
      vatId: body.vatId || "",
      register: body.register || "",
      registerCourt: body.registerCourt || "",
      updated: (/* @__PURE__ */ new Date()).toISOString()
    }
  }));
  return { success: true };
});

export { company_post as default };
//# sourceMappingURL=company.post.mjs.map
