import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const branding_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const client = getDynamoClient();
  await client.send(new PutCommand({
    TableName: "plexora-settings",
    Item: {
      settingId: "branding",
      scope: "global",
      brandName: body.brandName || "Plexora",
      brandTagline: body.brandTagline || "Business Platform",
      primaryColor: body.primaryColor || "#7C3AED",
      portalTitle: body.portalTitle || "Kundenportal",
      updated: (/* @__PURE__ */ new Date()).toISOString()
    }
  }));
  return { success: true };
});

export { branding_post as default };
//# sourceMappingURL=branding.post.mjs.map
