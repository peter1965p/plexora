import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { GetCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const DEFAULTS = {
  level1: { active: true, days: 5, fee: 0, text: "Wir m\xF6chten Sie freundlich daran erinnern, dass die folgende Rechnung noch offen ist." },
  level2: { active: true, days: 14, fee: 15, text: "Trotz unserer ersten Mahnung haben wir noch keinen Zahlungseingang verbuchen k\xF6nnen." },
  level3: { active: true, days: 30, fee: 40, inkasso: true, text: "Dies ist unsere letzte Mahnung. Bei Nichtbegleichung \xFCbergeben wir die Forderung an ein Inkassounternehmen." }
};
const dunning_get = defineEventHandler(async () => {
  const client = getDynamoClient();
  try {
    const result = await client.send(new GetCommand({
      TableName: "plexora-settings",
      Key: { settingId: "dunning", scope: "global" }
    }));
    return { settings: result.Item || DEFAULTS };
  } catch {
    return { settings: DEFAULTS };
  }
});

export { dunning_get as default };
//# sourceMappingURL=dunning.get.mjs.map
