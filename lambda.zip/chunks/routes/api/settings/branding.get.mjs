import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { GetCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const DEFAULTS = {
  brandName: "Plexora",
  brandTagline: "Business Platform",
  primaryColor: "#7C3AED",
  portalTitle: "Kundenportal"
};
const branding_get = defineEventHandler(async () => {
  const client = getDynamoClient();
  try {
    const result = await client.send(new GetCommand({
      TableName: "plexora-settings",
      Key: { settingId: "branding", scope: "global" }
    }));
    return { branding: result.Item || DEFAULTS };
  } catch {
    return { branding: DEFAULTS };
  }
});

export { branding_get as default };
//# sourceMappingURL=branding.get.mjs.map
