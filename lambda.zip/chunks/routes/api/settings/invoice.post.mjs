import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const invoice_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const client = getDynamoClient();
  await client.send(new PutCommand({
    TableName: "plexora-settings",
    Item: {
      settingId: "invoice",
      scope: "global",
      dueDays: body.dueDays || 7,
      dueText: body.dueText || "Zahlbar innerhalb von 7 Tagen netto",
      updated: (/* @__PURE__ */ new Date()).toISOString()
    }
  }));
  return { success: true };
});

export { invoice_post as default };
//# sourceMappingURL=invoice.post.mjs.map
