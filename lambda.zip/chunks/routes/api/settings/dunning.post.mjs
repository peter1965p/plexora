import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const dunning_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const client = getDynamoClient();
  await client.send(new PutCommand({
    TableName: "plexora-settings",
    Item: {
      settingId: "dunning",
      scope: "global",
      level1: body.level1,
      level2: body.level2,
      level3: body.level3,
      updated: (/* @__PURE__ */ new Date()).toISOString()
    }
  }));
  return { success: true };
});

export { dunning_post as default };
//# sourceMappingURL=dunning.post.mjs.map
