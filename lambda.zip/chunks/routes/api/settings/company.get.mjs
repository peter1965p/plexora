import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { GetCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const DEFAULTS = {
  legalName: "",
  representedBy: "",
  street: "",
  zipCity: "",
  country: "Deutschland",
  email: "",
  phone: "",
  vatId: "",
  register: "",
  registerCourt: ""
};
const company_get = defineEventHandler(async () => {
  const client = getDynamoClient();
  try {
    const result = await client.send(new GetCommand({
      TableName: "plexora-settings",
      Key: { settingId: "company", scope: "global" }
    }));
    return { company: { ...DEFAULTS, ...result.Item } };
  } catch {
    return { company: DEFAULTS };
  }
});

export { company_get as default };
//# sourceMappingURL=company.get.mjs.map
