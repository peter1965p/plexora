import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { GetCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const DEFAULTS = { dueDays: 7, dueText: "Zahlbar innerhalb von 7 Tagen netto" };
const invoice_get = defineEventHandler(async () => {
  const client = getDynamoClient();
  try {
    const result = await client.send(new GetCommand({
      TableName: "plexora-settings",
      Key: { settingId: "invoice", scope: "global" }
    }));
    return { settings: result.Item || DEFAULTS };
  } catch {
    return { settings: DEFAULTS };
  }
});

export { invoice_get as default };
//# sourceMappingURL=invoice.get.mjs.map
