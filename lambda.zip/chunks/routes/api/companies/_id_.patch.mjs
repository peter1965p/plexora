import { d as defineEventHandler, a as getRouterParam, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { ScanCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const _id__patch = defineEventHandler(async (event) => {
  var _a;
  const companyId = getRouterParam(event, "id");
  const body = await readBody(event);
  const client = getDynamoClient();
  const scan = await client.send(new ScanCommand({
    TableName: "plexora-companies",
    FilterExpression: "companyId = :id",
    ExpressionAttributeValues: { ":id": companyId }
  }));
  const existing = (_a = scan.Items) == null ? void 0 : _a[0];
  if (!existing) throw createError({ statusCode: 404, message: "Unternehmen nicht gefunden" });
  await client.send(new UpdateCommand({
    TableName: "plexora-companies",
    Key: { userId: existing.userId, companyId },
    UpdateExpression: "SET #nm = :nm, website = :ws, branche = :br, email = :em, phone = :ph, street = :st, zip = :zp, city = :ct, country = :co, notes = :no",
    ExpressionAttributeNames: { "#nm": "name" },
    ExpressionAttributeValues: {
      ":nm": body.name,
      ":ws": body.website || "",
      ":br": body.branche || "",
      ":em": body.email || "",
      ":ph": body.phone || "",
      ":st": body.street || "",
      ":zp": body.zip || "",
      ":ct": body.city || "",
      ":co": body.country || "",
      ":no": body.notes || ""
    }
  }));
  return { success: true };
});

export { _id__patch as default };
//# sourceMappingURL=_id_.patch.mjs.map
