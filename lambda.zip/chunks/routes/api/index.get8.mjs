import { d as defineEventHandler } from '../../nitro/nitro.mjs';
import { ScanCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_get = defineEventHandler(async () => {
  const client = getDynamoClient();
  const result = await client.send(new ScanCommand({ TableName: "plexora-support" }));
  return { tickets: result.Items || [] };
});

export { index_get as default };
//# sourceMappingURL=index.get8.mjs.map
