import { d as defineEventHandler, r as readBody } from '../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const client = getDynamoClient();
  const company = {
    userId: body.userId || "demo-user",
    companyId: randomUUID(),
    name: body.name,
    website: body.website || "",
    branche: body.branche || "",
    email: body.email || "",
    phone: body.phone || "",
    street: body.street || "",
    zip: body.zip || "",
    city: body.city || "",
    country: body.country || "",
    notes: body.notes || "",
    created: (/* @__PURE__ */ new Date()).toISOString()
  };
  await client.send(new PutCommand({ TableName: "plexora-companies", Item: company }));
  return { success: true, company };
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
