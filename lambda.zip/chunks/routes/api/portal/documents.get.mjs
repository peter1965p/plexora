import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { ScanCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const documents_get = defineEventHandler(async () => {
  const client = getDynamoClient();
  try {
    const result = await client.send(new ScanCommand({ TableName: "plexora-documents" }));
    return { documents: result.Items || [] };
  } catch {
    return { documents: [] };
  }
});

export { documents_get as default };
//# sourceMappingURL=documents.get.mjs.map
