import { d as defineEventHandler, g as getQuery } from '../../../nitro/nitro.mjs';
import { ScanCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const invoices_get = defineEventHandler(async (event) => {
  const email = getQuery(event).email;
  const client = getDynamoClient();
  const result = await client.send(new ScanCommand({ TableName: "plexora-finance" }));
  const all = result.Items || [];
  const filtered = email ? all.filter((i) => i.clientEmail === email) : [];
  return { invoices: filtered };
});

export { invoices_get as default };
//# sourceMappingURL=invoices.get.mjs.map
