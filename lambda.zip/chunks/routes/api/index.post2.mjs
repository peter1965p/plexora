import { d as defineEventHandler, r as readBody } from '../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const client = getDynamoClient();
  const contact = {
    userId: body.userId || "demo-user",
    contactId: randomUUID(),
    firstName: body.firstName,
    lastName: body.lastName,
    email: body.email,
    company: body.company || "",
    companyId: body.companyId || "",
    phone: body.phone || "",
    status: body.status || "lead",
    leadSource: body.leadSource || "manual",
    leadStatus: body.leadStatus || "new",
    utmSource: body.utmSource || "",
    utmMedium: body.utmMedium || "",
    utmCampaign: body.utmCampaign || "",
    utmContent: body.utmContent || "",
    utmTerm: body.utmTerm || "",
    landingPageId: body.landingPageId || "",
    score: body.score || 0,
    customerId: "",
    convertedAt: "",
    created: (/* @__PURE__ */ new Date()).toISOString()
  };
  await client.send(new PutCommand({ TableName: "plexora-contacts", Item: contact }));
  return { success: true, contact };
});

export { index_post as default };
//# sourceMappingURL=index.post2.mjs.map
