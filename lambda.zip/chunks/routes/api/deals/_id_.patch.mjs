import { d as defineEventHandler, a as getRouterParam, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { ScanCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const _id__patch = defineEventHandler(async (event) => {
  var _a;
  const dealId = getRouterParam(event, "id");
  const body = await readBody(event);
  const client = getDynamoClient();
  const scan = await client.send(new ScanCommand({
    TableName: "plexora-deals",
    FilterExpression: "dealId = :id",
    ExpressionAttributeValues: { ":id": dealId }
  }));
  const existing = (_a = scan.Items) == null ? void 0 : _a[0];
  if (!existing) throw createError({ statusCode: 404, message: "Deal nicht gefunden" });
  await client.send(new UpdateCommand({
    TableName: "plexora-deals",
    Key: { userId: existing.userId, dealId },
    UpdateExpression: "SET #nm = :nm, #vl = :vl, stage = :sg, prob = :pb, #st = :st",
    ExpressionAttributeNames: { "#nm": "name", "#vl": "value", "#st": "status" },
    ExpressionAttributeValues: {
      ":nm": body.name,
      ":vl": body.value,
      ":sg": body.stage,
      ":pb": body.prob,
      ":st": body.status
    }
  }));
  return { success: true };
});

export { _id__patch as default };
//# sourceMappingURL=_id_.patch.mjs.map
