import { d as defineEventHandler, a as getRouterParam, c as createError } from '../../../../nitro/nitro.mjs';
import { ScanCommand, PutCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const convert_post = defineEventHandler(async (event) => {
  var _a;
  const contactId = getRouterParam(event, "id");
  const client = getDynamoClient();
  const scan = await client.send(new ScanCommand({
    TableName: "plexora-contacts",
    FilterExpression: "contactId = :id",
    ExpressionAttributeValues: { ":id": contactId }
  }));
  const existing = (_a = scan.Items) == null ? void 0 : _a[0];
  if (!existing) throw createError({ statusCode: 404, message: "Kontakt nicht gefunden" });
  if (existing.customerId) {
    return { success: true, alreadyConverted: true, customerId: existing.customerId };
  }
  const customerId = randomUUID();
  const convertedAt = (/* @__PURE__ */ new Date()).toISOString();
  const customer = {
    userId: existing.userId,
    customerId,
    contactId: existing.contactId,
    firstName: existing.firstName,
    lastName: existing.lastName,
    email: existing.email,
    company: existing.company || "",
    companyId: existing.companyId || "",
    phone: existing.phone || "",
    created: convertedAt
  };
  await client.send(new PutCommand({ TableName: "plexora-customers", Item: customer }));
  await client.send(new UpdateCommand({
    TableName: "plexora-contacts",
    Key: { userId: existing.userId, contactId },
    UpdateExpression: "SET customerId = :cid, convertedAt = :ca, #st = :st",
    ExpressionAttributeNames: { "#st": "status" },
    ExpressionAttributeValues: {
      ":cid": customerId,
      ":ca": convertedAt,
      ":st": "customer"
    }
  }));
  return { success: true, customerId, customer };
});

export { convert_post as default };
//# sourceMappingURL=convert.post.mjs.map
