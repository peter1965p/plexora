import { d as defineEventHandler, a as getRouterParam, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { ScanCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const _id__patch = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i;
  const contactId = getRouterParam(event, "id");
  const body = await readBody(event);
  const client = getDynamoClient();
  const scan = await client.send(new ScanCommand({
    TableName: "plexora-contacts",
    FilterExpression: "contactId = :id",
    ExpressionAttributeValues: { ":id": contactId }
  }));
  const existing = (_a = scan.Items) == null ? void 0 : _a[0];
  if (!existing) throw createError({ statusCode: 404, message: "Kontakt nicht gefunden" });
  await client.send(new UpdateCommand({
    TableName: "plexora-contacts",
    Key: { userId: existing.userId, contactId },
    UpdateExpression: "SET firstName = :fn, lastName = :ln, email = :em, company = :co, companyId = :cid, phone = :ph, #st = :st, leadSource = :ls, leadStatus = :lst, score = :sc",
    ExpressionAttributeNames: { "#st": "status" },
    ExpressionAttributeValues: {
      ":fn": body.firstName,
      ":ln": body.lastName,
      ":em": body.email,
      ":co": body.company || "",
      ":cid": (_c = (_b = body.companyId) != null ? _b : existing.companyId) != null ? _c : "",
      ":ph": body.phone || "",
      ":st": body.status,
      ":ls": (_e = (_d = body.leadSource) != null ? _d : existing.leadSource) != null ? _e : "manual",
      ":lst": (_g = (_f = body.leadStatus) != null ? _f : existing.leadStatus) != null ? _g : "new",
      ":sc": (_i = (_h = body.score) != null ? _h : existing.score) != null ? _i : 0
    }
  }));
  return { success: true };
});

export { _id__patch as default };
//# sourceMappingURL=_id_.patch.mjs.map
