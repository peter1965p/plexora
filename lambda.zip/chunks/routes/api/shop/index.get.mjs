import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { ScanCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_get = defineEventHandler(async () => {
  const client = getDynamoClient();
  try {
    const result = await client.send(new ScanCommand({
      TableName: "plexora-products",
      FilterExpression: "#st = :active",
      ExpressionAttributeNames: { "#st": "status" },
      ExpressionAttributeValues: { ":active": "active" }
    }));
    return { products: result.Items || [] };
  } catch {
    return { products: [] };
  }
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
