import { d as defineEventHandler, a as getRouterParam, c as createError } from '../../../../nitro/nitro.mjs';
import { ScanCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_get = defineEventHandler(async (event) => {
  var _a;
  const productId = getRouterParam(event, "id");
  const client = getDynamoClient();
  const result = await client.send(new ScanCommand({
    TableName: "plexora-products",
    FilterExpression: "productId = :id",
    ExpressionAttributeValues: { ":id": productId }
  }));
  const product = (_a = result.Items) == null ? void 0 : _a[0];
  if (!product) throw createError({ statusCode: 404, message: "Produkt nicht gefunden" });
  return { product };
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
