import { d as defineEventHandler, r as readBody, c as createError, b as getHeader, u as useRuntimeConfig } from '../../../nitro/nitro.mjs';
import Stripe from 'stripe';
import { GetCommand, ScanCommand, PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_post = defineEventHandler(async (event) => {
  var _a, _b;
  const body = await readBody(event);
  const config = useRuntimeConfig();
  const stripe = new Stripe(config.stripeSecretKey);
  const dynamo = getDynamoClient();
  let brandName = "Plexora";
  try {
    const bs = await dynamo.send(new GetCommand({ TableName: "plexora-settings", Key: { settingId: "branding", scope: "global" } }));
    if ((_a = bs.Item) == null ? void 0 : _a.brandName) brandName = bs.Item.brandName;
  } catch {
  }
  const lineItems = [];
  const cartItems = body.items || [];
  for (const item of cartItems) {
    const result = await dynamo.send(new ScanCommand({
      TableName: "plexora-products",
      FilterExpression: "productId = :id",
      ExpressionAttributeValues: { ":id": item.productId }
    }));
    const product = (_b = result.Items) == null ? void 0 : _b[0];
    if (!product) continue;
    lineItems.push({
      price_data: {
        currency: product.currency || "eur",
        product_data: {
          name: product.name,
          description: product.description || void 0,
          images: product.image ? [product.image] : void 0
        },
        unit_amount: Math.round(product.price * 100)
        // Stripe erwartet Cents
      },
      quantity: item.quantity || 1
    });
  }
  if (!lineItems.length) throw createError({ statusCode: 400, message: "Keine g\xFCltigen Produkte" });
  const orderId = randomUUID();
  await dynamo.send(new PutCommand({
    TableName: "plexora-orders",
    Item: {
      userId: body.userId || "guest",
      orderId,
      items: cartItems,
      status: "pending",
      email: body.email || "",
      created: (/* @__PURE__ */ new Date()).toISOString()
    }
  }));
  const origin = getHeader(event, "origin") || "http://localhost:3001";
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card"],
    line_items: lineItems,
    mode: "payment",
    success_url: `${origin}/shop/success?session_id={CHECKOUT_SESSION_ID}&order_id=${orderId}`,
    cancel_url: `${origin}/shop/cart`,
    customer_email: body.email || void 0,
    metadata: {
      orderId,
      userId: body.userId || "guest"
    }
  });
  return { sessionId: session.id, url: session.url };
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
