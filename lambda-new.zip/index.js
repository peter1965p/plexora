// ESM wrapper for Lambda
const { handler } = await import('./index.mjs');
export { handler };
