import { d as defineEventHandler, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const BUCKET = "plexora-files";
const s3Upload_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const { fileBase64, fileName, prefix } = body;
  if (!fileBase64 || !fileName) {
    throw createError({ statusCode: 400, statusMessage: "fileBase64 und fileName erforderlich" });
  }
  const client = new S3Client({ region: "eu-central-1" });
  const base64Data = fileBase64.replace(/^data:[^;]+;base64,/, "");
  const buffer = Buffer.from(base64Data, "base64");
  const key = `${prefix || ""}${fileName}`;
  const ext = ((_a = fileName.split(".").pop()) == null ? void 0 : _a.toLowerCase()) || "jpg";
  const mimeMap = { jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", gif: "image/gif", webp: "image/webp", svg: "image/svg+xml" };
  const contentType = mimeMap[ext] || "application/octet-stream";
  await client.send(new PutObjectCommand({
    Bucket: BUCKET,
    Key: key,
    Body: buffer,
    ContentType: contentType
  }));
  return { success: true, key, url: `https://${BUCKET}.s3.eu-central-1.amazonaws.com/${key}` };
});

export { s3Upload_post as default };
//# sourceMappingURL=s3-upload.post.mjs.map
