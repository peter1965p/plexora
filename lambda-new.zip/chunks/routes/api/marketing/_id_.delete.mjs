import { d as defineEventHandler, a as getRouterParam, c as createError } from '../../../nitro/nitro.mjs';
import { ScanCommand, DeleteCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const _id__delete = defineEventHandler(async (event) => {
  var _a;
  const campaignId = getRouterParam(event, "id");
  const client = getDynamoClient();
  const scan = await client.send(new ScanCommand({
    TableName: "plexora-marketing",
    FilterExpression: "campaignId = :id",
    ExpressionAttributeValues: { ":id": campaignId }
  }));
  const existing = (_a = scan.Items) == null ? void 0 : _a[0];
  if (!existing) throw createError({ statusCode: 404, message: "Kampagne nicht gefunden" });
  await client.send(new DeleteCommand({
    TableName: "plexora-marketing",
    Key: { userId: existing.userId, campaignId }
  }));
  return { success: true };
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
