import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { ScanCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const stats_get = defineEventHandler(async () => {
  const client = getDynamoClient();
  const contacts = await client.send(new ScanCommand({
    TableName: "plexora-contacts",
    FilterExpression: "leadSource = :ls",
    ExpressionAttributeValues: { ":ls": "landingpage" }
  }));
  const stats = {};
  for (const c of contacts.Items || []) {
    const key = c.utmCampaign || "unbekannt";
    stats[key] = (stats[key] || 0) + 1;
  }
  return { stats };
});

export { stats_get as default };
//# sourceMappingURL=stats.get.mjs.map
