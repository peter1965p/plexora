import { d as defineEventHandler, a as getRouterParam, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { ScanCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const _id__patch = defineEventHandler(async (event) => {
  var _a;
  const campaignId = getRouterParam(event, "id");
  const body = await readBody(event);
  const client = getDynamoClient();
  const scan = await client.send(new ScanCommand({
    TableName: "plexora-marketing",
    FilterExpression: "campaignId = :id",
    ExpressionAttributeValues: { ":id": campaignId }
  }));
  const existing = (_a = scan.Items) == null ? void 0 : _a[0];
  if (!existing) throw createError({ statusCode: 404, message: "Kampagne nicht gefunden" });
  await client.send(new UpdateCommand({
    TableName: "plexora-marketing",
    Key: { userId: existing.userId, campaignId },
    UpdateExpression: "SET #nm = :nm, slug = :sl, formId = :fi, headline = :hl, subtext = :st, headerImageUrl = :hi, accentColor = :ac, utmSource = :us, utmMedium = :um, utmCampaign = :uc, active = :av",
    ExpressionAttributeNames: { "#nm": "name" },
    ExpressionAttributeValues: {
      ":nm": body.name || "",
      ":sl": body.slug || "",
      ":fi": body.formId || "",
      ":hl": body.headline || "",
      ":st": body.subtext || "",
      ":hi": body.headerImageUrl || "",
      ":ac": body.accentColor || "#6C3FE8",
      ":us": body.utmSource || "",
      ":um": body.utmMedium || "",
      ":uc": body.utmCampaign || "",
      ":av": body.active !== false
    }
  }));
  return { success: true };
});

export { _id__patch as default };
//# sourceMappingURL=_id_.patch.mjs.map
