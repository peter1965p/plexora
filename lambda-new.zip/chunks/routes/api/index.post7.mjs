import { d as defineEventHandler, r as readBody } from '../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const client = getDynamoClient();
  const employee = {
    userId: body.userId || "demo-user",
    employeeId: randomUUID(),
    firstName: body.firstName,
    lastName: body.lastName,
    email: body.email,
    department: body.department,
    role: body.role,
    status: body.status || "active",
    startDate: body.startDate,
    created: (/* @__PURE__ */ new Date()).toISOString()
  };
  await client.send(new PutCommand({ TableName: "plexora-hr", Item: employee }));
  return { success: true, employee };
});

export { index_post as default };
//# sourceMappingURL=index.post7.mjs.map
