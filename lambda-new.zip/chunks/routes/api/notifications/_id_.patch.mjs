import { d as defineEventHandler, a as getRouterParam, r as readBody } from '../../../nitro/nitro.mjs';
import { UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const _id__patch = defineEventHandler(async (event) => {
  const notificationId = getRouterParam(event, "id");
  const body = await readBody(event);
  const dynamo = getDynamoClient();
  await dynamo.send(new UpdateCommand({
    TableName: "plexora-notifications",
    Key: { notificationId, userId: body.userId },
    UpdateExpression: "SET #r = :r",
    ExpressionAttributeNames: { "#r": "read" },
    ExpressionAttributeValues: { ":r": true }
  }));
  return { success: true };
});

export { _id__patch as default };
//# sourceMappingURL=_id_.patch.mjs.map
