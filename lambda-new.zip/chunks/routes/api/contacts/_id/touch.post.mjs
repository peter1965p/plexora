import { d as defineEventHandler, a as getRouterParam, c as createError } from '../../../../nitro/nitro.mjs';
import { ScanCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const touch_post = defineEventHandler(async (event) => {
  var _a;
  const contactId = getRouterParam(event, "id");
  const client = getDynamoClient();
  const scan = await client.send(new ScanCommand({
    TableName: "plexora-contacts",
    FilterExpression: "contactId = :id",
    ExpressionAttributeValues: { ":id": contactId }
  }));
  const existing = (_a = scan.Items) == null ? void 0 : _a[0];
  if (!existing) throw createError({ statusCode: 404, message: "Kontakt nicht gefunden" });
  await client.send(new UpdateCommand({
    TableName: "plexora-contacts",
    Key: { userId: existing.userId, contactId },
    UpdateExpression: "SET accessCount = if_not_exists(accessCount, :zero) + :inc, lastAccessedAt = :now",
    ExpressionAttributeValues: {
      ":zero": 0,
      ":inc": 1,
      ":now": (/* @__PURE__ */ new Date()).toISOString()
    }
  }));
  return { success: true };
});

export { touch_post as default };
//# sourceMappingURL=touch.post.mjs.map
