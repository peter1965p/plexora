import { d as defineEventHandler, r as readBody, c as createError, u as useRuntimeConfig } from '../../../nitro/nitro.mjs';
import Stripe from 'stripe';
import { GetCommand, ScanCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const checkout_post = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const body = await readBody(event);
  const dynamo = getDynamoClient();
  const config = useRuntimeConfig();
  let stripeKey = config.stripeSecretKey;
  try {
    const ps = await dynamo.send(new GetCommand({
      TableName: "plexora-settings",
      Key: { settingId: "payment", scope: "global" }
    }));
    if ((_a = ps.Item) == null ? void 0 : _a.stripeSecretKey) stripeKey = ps.Item.stripeSecretKey;
  } catch {
  }
  const stripe = new Stripe(stripeKey);
  const scan = await dynamo.send(new ScanCommand({
    TableName: "plexora-products",
    FilterExpression: "productId = :id",
    ExpressionAttributeValues: { ":id": body.productId }
  }));
  const product = (_b = scan.Items) == null ? void 0 : _b[0];
  if (!product) throw createError({ statusCode: 404, message: "Produkt nicht gefunden" });
  const netto = Number(product.price) || 0;
  const vatRate = ((_c = product.vatRate) != null ? _c : 19) / 100;
  const brutto = Math.round(netto * (1 + vatRate) * 100);
  const session = await stripe.checkout.sessions.create({
    billing_address_collection: "required",
    payment_method_types: ["card"],
    mode: "payment",
    customer_email: body.email || void 0,
    line_items: [{
      price_data: {
        currency: "eur",
        product_data: {
          name: product.name,
          description: product.description || ""
        },
        unit_amount: brutto
      },
      quantity: body.quantity || 1
    }],
    success_url: `${body.baseUrl || "https://plexora.paeffgen-it.de"}/shop/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${body.baseUrl || "https://plexora.paeffgen-it.de"}/shop`,
    metadata: {
      type: "shop_purchase",
      productId: product.productId,
      productName: product.name,
      productUserId: product.userId || "demo-user",
      quantity: String(body.quantity || 1)
    }
  });
  return { url: session.url };
});

export { checkout_post as default };
//# sourceMappingURL=checkout.post.mjs.map
