import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { ScanCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_get = defineEventHandler(async () => {
  const dynamo = getDynamoClient();
  const res = await dynamo.send(new ScanCommand({ TableName: "plexora-purchase-orders" }));
  return { orders: (res.Items || []).sort((a, b) => {
    var _a;
    return (_a = b.created) == null ? void 0 : _a.localeCompare(a.created);
  }) };
});

export { index_get as default };
//# sourceMappingURL=index.get2.mjs.map
