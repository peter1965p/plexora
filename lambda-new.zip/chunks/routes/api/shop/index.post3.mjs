import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const dynamo = getDynamoClient();
  const supplierId = randomUUID();
  await dynamo.send(new PutCommand({
    TableName: "plexora-suppliers",
    Item: { supplierId, userId: "global", ...body, created: (/* @__PURE__ */ new Date()).toISOString() }
  }));
  return { success: true, supplierId };
});

export { index_post as default };
//# sourceMappingURL=index.post3.mjs.map
