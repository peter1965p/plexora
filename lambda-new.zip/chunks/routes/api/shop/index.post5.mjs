import { d as defineEventHandler, e as readRawBody, b as getHeader, u as useRuntimeConfig } from '../../../nitro/nitro.mjs';
import Stripe from 'stripe';
import { ScanCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { SESClient, SendEmailCommand } from '@aws-sdk/client-ses';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_post = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const config = useRuntimeConfig();
  const stripe = new Stripe(config.stripeSecretKey);
  const dynamo = getDynamoClient();
  const body = await readRawBody(event);
  const sig = getHeader(event, "stripe-signature");
  let stripeEvent;
  try {
    stripeEvent = stripe.webhooks.constructEvent(body, sig, config.stripeWebhookSecret || "");
  } catch {
    stripeEvent = JSON.parse(body);
  }
  if (stripeEvent.type === "checkout.session.completed") {
    const session = stripeEvent.data.object;
    const orderId = (_a = session.metadata) == null ? void 0 : _a.orderId;
    const email = session.customer_email || ((_b = session.customer_details) == null ? void 0 : _b.email);
    if (orderId) {
      const scan = await dynamo.send(new ScanCommand({
        TableName: "plexora-orders",
        FilterExpression: "orderId = :id",
        ExpressionAttributeValues: { ":id": orderId }
      }));
      const order = (_c = scan.Items) == null ? void 0 : _c[0];
      if (order) {
        await dynamo.send(new UpdateCommand({
          TableName: "plexora-orders",
          Key: { userId: order.userId, orderId },
          UpdateExpression: "SET #st = :st, stripeSessionId = :sid, paidAt = :pa",
          ExpressionAttributeNames: { "#st": "status" },
          ExpressionAttributeValues: { ":st": "paid", ":sid": session.id, ":pa": (/* @__PURE__ */ new Date()).toISOString() }
        }));
      }
      if (email) {
        try {
          const ses = new SESClient({
            region: "eu-central-1",
            credentials: {
              accessKeyId: config.awsAccessKeyId.replace(/^"|"$/g, ""),
              secretAccessKey: config.awsSecretAccessKey.replace(/^"|"$/g, "")
            }
          });
          await ses.send(new SendEmailCommand({
            Source: `billing@paeffgen-it.de`,
            Destination: { ToAddresses: [email] },
            Message: {
              Subject: { Data: `Bestellung best\xE4tigt \u2014 ${orderId.slice(0, 8).toUpperCase()}` },
              Body: {
                Html: {
                  Data: `
                    <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
                      <h2 style="color:#7C3AED">Bestellung best\xE4tigt!</h2>
                      <p>Vielen Dank f\xFCr Ihre Bestellung.</p>
                      <p>Bestellnummer: <strong>${orderId.slice(0, 8).toUpperCase()}</strong></p>
                      <p>Wir bearbeiten Ihre Bestellung und melden uns in K\xFCrze.</p>
                    </div>
                  `
                }
              }
            }
          }));
        } catch (e) {
          console.log("Mail Fehler:", e.message);
        }
      }
    }
  }
  return { received: true };
});

export { index_post as default };
//# sourceMappingURL=index.post5.mjs.map
