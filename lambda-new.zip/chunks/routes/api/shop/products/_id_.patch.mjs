import { d as defineEventHandler, a as getRouterParam, r as readBody } from '../../../../nitro/nitro.mjs';
import { UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const _id__patch = defineEventHandler(async (event) => {
  var _a;
  const productId = getRouterParam(event, "id");
  const body = await readBody(event);
  const dynamo = getDynamoClient();
  const userId = body.userId || "demo-user";
  await dynamo.send(new UpdateCommand({
    TableName: "plexora-products",
    Key: { userId, productId },
    UpdateExpression: "SET #n = :n, price = :p, category = :c, description = :d, longDescription = :ld, features = :ft, priceModel = :pm, stock = :s, minStock = :ms, image = :img, vatRate = :vr, supplierId = :sid, updated = :u",
    ExpressionAttributeNames: { "#n": "name" },
    ExpressionAttributeValues: {
      ":n": body.name,
      ":p": body.price,
      ":c": body.category,
      ":d": body.description || "",
      ":ld": body.longDescription || "",
      ":ft": body.features || [],
      ":pm": body.priceModel || "einmalig",
      ":s": body.stock,
      ":ms": body.minStock || 10,
      ":img": body.image || "",
      ":vr": (_a = body.vatRate) != null ? _a : 19,
      ":sid": body.supplierId || "",
      ":u": (/* @__PURE__ */ new Date()).toISOString()
    }
  }));
  return { success: true };
});

export { _id__patch as default };
//# sourceMappingURL=_id_.patch.mjs.map
