import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const client = getDynamoClient();
  const product = {
    userId: body.userId || "demo-user",
    productId: randomUUID(),
    name: body.name,
    description: body.description || "",
    price: Number(body.price),
    currency: body.currency || "eur",
    category: body.category || "general",
    image: body.image || "",
    stock: Number(body.stock) || 0,
    status: body.status || "active",
    created: (/* @__PURE__ */ new Date()).toISOString()
  };
  await client.send(new PutCommand({ TableName: "plexora-products", Item: product }));
  return { success: true, product };
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
