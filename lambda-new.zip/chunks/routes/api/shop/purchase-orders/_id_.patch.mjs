import { d as defineEventHandler, a as getRouterParam, r as readBody } from '../../../../nitro/nitro.mjs';
import { UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const _id__patch = defineEventHandler(async (event) => {
  const orderId = getRouterParam(event, "id");
  const body = await readBody(event);
  const dynamo = getDynamoClient();
  await dynamo.send(new UpdateCommand({
    TableName: "plexora-purchase-orders",
    Key: { orderId, userId: "global" },
    UpdateExpression: "SET #st = :st, updatedAt = :u",
    ExpressionAttributeNames: { "#st": "status" },
    ExpressionAttributeValues: { ":st": body.status, ":u": (/* @__PURE__ */ new Date()).toISOString() }
  }));
  return { success: true };
});

export { _id__patch as default };
//# sourceMappingURL=_id_.patch.mjs.map
