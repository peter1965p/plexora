import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import { GetCommand, PutCommand } from '@aws-sdk/lib-dynamodb';
import { SESClient, SendRawEmailCommand } from '@aws-sdk/client-ses';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const dynamo = getDynamoClient();
  const orderId = randomUUID();
  let supplier = {};
  if (body.supplierId) {
    try {
      const { ScanCommand } = await import('@aws-sdk/lib-dynamodb');
      const res = await dynamo.send(new ScanCommand({
        TableName: "plexora-suppliers",
        FilterExpression: "supplierId = :id",
        ExpressionAttributeValues: { ":id": body.supplierId }
      }));
      supplier = ((_a = res.Items) == null ? void 0 : _a[0]) || {};
    } catch {
    }
  }
  let branding = { brandName: "Plexora" };
  try {
    const bs = await dynamo.send(new GetCommand({ TableName: "plexora-settings", Key: { settingId: "branding", scope: "global" } }));
    if (bs.Item) branding = bs.Item;
  } catch {
  }
  await dynamo.send(new PutCommand({
    TableName: "plexora-purchase-orders",
    Item: {
      orderId,
      userId: "global",
      productId: body.productId,
      productName: body.productName,
      supplierId: body.supplierId || "",
      supplierName: supplier.name || "\u2014",
      quantity: body.quantity,
      status: "offen",
      notes: body.notes || "",
      created: (/* @__PURE__ */ new Date()).toISOString()
    }
  }));
  if (supplier.email) {
    try {
      const ses = new SESClient({ region: "eu-central-1" });
      const subject = `Bestellung: ${body.productName} \u2014 ${branding.brandName}`;
      const boundary = `----=_Part_${Date.now()}`;
      const rawEmail = [
        `From: ${branding.brandName} <billing@paeffgen-it.de>`,
        `To: ${supplier.email}`,
        `Subject: ${subject}`,
        `MIME-Version: 1.0`,
        `Content-Type: text/html; charset=UTF-8`,
        ``,
        `<html><body style="font-family:sans-serif;color:#333;max-width:600px;margin:0 auto">`,
        `<h2>Bestellanfrage von ${branding.brandName}</h2>`,
        `<p>Sehr geehrte Damen und Herren,</p>`,
        `<p>wir m\xF6chten folgende Artikel bestellen:</p>`,
        `<table style="border-collapse:collapse;width:100%;margin:20px 0">`,
        `<tr style="background:#f5f5f5"><td style="padding:8px;border:1px solid #eee"><strong>Produkt</strong></td><td style="padding:8px;border:1px solid #eee"><strong>${body.productName}</strong></td></tr>`,
        `<tr><td style="padding:8px;border:1px solid #eee">Menge</td><td style="padding:8px;border:1px solid #eee"><strong>${body.quantity} St\xFCck</strong></td></tr>`,
        body.notes ? `<tr><td style="padding:8px;border:1px solid #eee">Hinweise</td><td style="padding:8px;border:1px solid #eee">${body.notes}</td></tr>` : "",
        `<tr><td style="padding:8px;border:1px solid #eee">Bestell-Nr.</td><td style="padding:8px;border:1px solid #eee">${orderId.slice(0, 8).toUpperCase()}</td></tr>`,
        `</table>`,
        `<p>Bitte best\xE4tigen Sie die Bestellung per R\xFCckantwort.</p>`,
        `<p>Mit freundlichen Gr\xFC\xDFen<br>${branding.brandName}</p>`,
        `</body></html>`
      ].join("\r\n");
      await ses.send(new SendRawEmailCommand({ RawMessage: { Data: Buffer.from(rawEmail) } }));
    } catch (err) {
      console.error("Bestellmail fehlgeschlagen:", err);
    }
  }
  return { success: true, orderId };
});

export { index_post as default };
//# sourceMappingURL=index.post2.mjs.map
