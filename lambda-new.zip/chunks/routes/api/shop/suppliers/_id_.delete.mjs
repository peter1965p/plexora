import { d as defineEventHandler, a as getRouterParam } from '../../../../nitro/nitro.mjs';
import { DeleteCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const _id__delete = defineEventHandler(async (event) => {
  const supplierId = getRouterParam(event, "id");
  const dynamo = getDynamoClient();
  await dynamo.send(new DeleteCommand({ TableName: "plexora-suppliers", Key: { supplierId, userId: "global" } }));
  return { success: true };
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
