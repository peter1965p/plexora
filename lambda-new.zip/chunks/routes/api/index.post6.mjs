import { d as defineEventHandler, r as readBody } from '../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const client = getDynamoClient();
  const form = {
    formId: randomUUID(),
    title: body.title,
    description: body.description || "",
    fields: body.fields || [],
    submitLabel: body.submitLabel || "Absenden",
    successMsg: body.successMsg || "Vielen Dank!",
    notifyEmail: body.notifyEmail || "",
    created: (/* @__PURE__ */ new Date()).toISOString()
  };
  await client.send(new PutCommand({ TableName: "plexora-forms", Item: form }));
  return { success: true, form };
});

export { index_post as default };
//# sourceMappingURL=index.post6.mjs.map
