import { d as defineEventHandler, r as readBody } from '../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_post = defineEventHandler(async (event) => {
  var _a, _b;
  const body = await readBody(event);
  const client = getDynamoClient();
  const page = {
    pageId: randomUUID(),
    slug: (_a = body.slug) == null ? void 0 : _a.toLowerCase().replace(/\s+/g, "-"),
    title: body.title,
    blocks: body.blocks || [],
    inNav: (_b = body.inNav) != null ? _b : false,
    navLabel: body.navLabel || body.title,
    status: body.status || "draft",
    created: (/* @__PURE__ */ new Date()).toISOString(),
    updated: (/* @__PURE__ */ new Date()).toISOString()
  };
  await client.send(new PutCommand({ TableName: "plexora-pages", Item: page }));
  return { success: true, page };
});

export { index_post as default };
//# sourceMappingURL=index.post9.mjs.map
