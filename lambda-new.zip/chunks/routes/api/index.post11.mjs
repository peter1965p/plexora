import { d as defineEventHandler, r as readBody } from '../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const client = getDynamoClient();
  const ticket = {
    userId: body.userId || "demo-user",
    ticketId: randomUUID(),
    title: body.title,
    client: body.client,
    priority: body.priority || "medium",
    status: body.status || "open",
    created: (/* @__PURE__ */ new Date()).toISOString(),
    updated: (/* @__PURE__ */ new Date()).toISOString()
  };
  await client.send(new PutCommand({ TableName: "plexora-support", Item: ticket }));
  return { success: true, ticket };
});

export { index_post as default };
//# sourceMappingURL=index.post11.mjs.map
