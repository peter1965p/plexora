import { d as defineEventHandler, r as readBody } from '../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const client = getDynamoClient();
  const deal = {
    userId: body.userId || "demo-user",
    dealId: randomUUID(),
    name: body.name,
    value: body.value,
    stage: body.stage,
    prob: body.prob || 0,
    status: body.status || "info",
    created: (/* @__PURE__ */ new Date()).toISOString()
  };
  await client.send(
    new PutCommand({
      TableName: "plexora-deals",
      Item: deal
    })
  );
  return { success: true, deal };
});

export { index_post as default };
//# sourceMappingURL=index.post4.mjs.map
