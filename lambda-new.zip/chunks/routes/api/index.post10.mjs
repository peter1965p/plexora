import { d as defineEventHandler, r as readBody } from '../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const client = getDynamoClient();
  const project = {
    userId: body.userId || "demo-user",
    projectId: randomUUID(),
    name: body.name,
    description: body.description || "",
    companyId: body.companyId || "",
    contactId: body.contactId || "",
    team: body.team || "",
    deadline: body.deadline || "",
    progress: (_a = body.progress) != null ? _a : 0,
    status: body.status || "active",
    priority: body.priority || "medium",
    notes: body.notes || "",
    created: (/* @__PURE__ */ new Date()).toISOString()
  };
  await client.send(new PutCommand({ TableName: "plexora-projects", Item: project }));
  return { success: true, project };
});

export { index_post as default };
//# sourceMappingURL=index.post10.mjs.map
