import { d as defineEventHandler, r as readBody } from '../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const client = getDynamoClient();
  const contract = {
    userId: body.userId || "demo-user",
    contractId: randomUUID(),
    title: body.title,
    contractNumber: body.contractNumber || "",
    type: body.type || "service",
    companyId: body.companyId || "",
    contactId: body.contactId || "",
    startDate: body.startDate || "",
    endDate: body.endDate || "",
    value: body.value || "",
    billingCycle: body.billingCycle || "monthly",
    autoRenew: !!body.autoRenew,
    noticePeriodDays: body.noticePeriodDays || 0,
    status: body.status || "active",
    notes: body.notes || "",
    created: (/* @__PURE__ */ new Date()).toISOString()
  };
  await client.send(new PutCommand({ TableName: "plexora-contracts", Item: contract }));
  return { success: true, contract };
});

export { index_post as default };
//# sourceMappingURL=index.post3.mjs.map
