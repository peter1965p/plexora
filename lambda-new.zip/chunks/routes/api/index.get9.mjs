import { d as defineEventHandler, g as getQuery } from '../../nitro/nitro.mjs';
import { ScanCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_get = defineEventHandler(async (event) => {
  const userId = getQuery(event).userId || "demo-user";
  const dynamo = getDynamoClient();
  try {
    const res = await dynamo.send(new ScanCommand({
      TableName: "plexora-notifications",
      FilterExpression: "userId = :uid AND #r = :r",
      ExpressionAttributeNames: { "#r": "read" },
      ExpressionAttributeValues: { ":uid": userId, ":r": false }
    }));
    return { notifications: res.Items || [] };
  } catch {
    return { notifications: [] };
  }
});

export { index_get as default };
//# sourceMappingURL=index.get9.mjs.map
