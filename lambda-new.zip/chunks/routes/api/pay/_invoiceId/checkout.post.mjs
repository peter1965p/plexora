import { d as defineEventHandler, a as getRouterParam, c as createError, b as getHeader, u as useRuntimeConfig } from '../../../../nitro/nitro.mjs';
import { ScanCommand, GetCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../../_/dynamodb.mjs';
import Stripe from 'stripe';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const checkout_post = defineEventHandler(async (event) => {
  var _a, _b;
  const invoiceId = getRouterParam(event, "invoiceId");
  const dynamo = getDynamoClient();
  const scan = await dynamo.send(new ScanCommand({
    TableName: "plexora-finance",
    FilterExpression: "invoiceId = :id",
    ExpressionAttributeValues: { ":id": invoiceId }
  }));
  const invoice = (_a = scan.Items) == null ? void 0 : _a[0];
  if (!invoice) throw createError({ statusCode: 404, message: "Rechnung nicht gefunden" });
  const ps = await dynamo.send(new GetCommand({
    TableName: "plexora-settings",
    Key: { settingId: "payment", scope: "global" }
  }));
  const paySettings = ps.Item;
  const bs = await dynamo.send(new GetCommand({
    TableName: "plexora-settings",
    Key: { settingId: "branding", scope: "global" }
  }));
  const brandName = ((_b = bs.Item) == null ? void 0 : _b.brandName) || "Plexora";
  const gateway = (paySettings == null ? void 0 : paySettings.activeGateway) || "stripe";
  const origin = getHeader(event, "origin") || "https://plexora.paeffgen-it.de";
  const netto = Number(invoice.amount) || 0;
  const brutto = Math.round(netto * 1.19 * 100);
  if (gateway === "stripe") {
    const secretKey = (paySettings == null ? void 0 : paySettings.stripeSecretKey) || useRuntimeConfig().stripeSecretKey;
    const stripe = new Stripe(secretKey);
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [{
        price_data: {
          currency: "eur",
          product_data: {
            name: `Rechnung ${invoice.number || (invoiceId == null ? void 0 : invoiceId.slice(0, 8).toUpperCase())} \u2014 ${brandName}`
          },
          unit_amount: brutto
        },
        quantity: 1
      }],
      mode: "payment",
      success_url: `${origin}/pay/${invoiceId}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/pay/${invoiceId}`,
      customer_email: invoice.clientEmail || void 0,
      metadata: { invoiceId, userId: invoice.userId || "", source: "invoice-pay" }
    });
    return { url: session.url };
  }
  throw createError({ statusCode: 400, message: `Gateway ${gateway} noch nicht implementiert` });
});

export { checkout_post as default };
//# sourceMappingURL=checkout.post.mjs.map
