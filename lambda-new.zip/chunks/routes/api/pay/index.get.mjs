import { d as defineEventHandler, a as getRouterParam, c as createError } from '../../../nitro/nitro.mjs';
import { ScanCommand, GetCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_get = defineEventHandler(async (event) => {
  var _a, _b;
  const invoiceId = getRouterParam(event, "invoiceId");
  const dynamo = getDynamoClient();
  const scan = await dynamo.send(new ScanCommand({
    TableName: "plexora-finance",
    FilterExpression: "invoiceId = :id",
    ExpressionAttributeValues: { ":id": invoiceId }
  }));
  const invoice = (_a = scan.Items) == null ? void 0 : _a[0];
  if (!invoice) throw createError({ statusCode: 404, message: "Rechnung nicht gefunden" });
  const ps = await dynamo.send(new GetCommand({
    TableName: "plexora-settings",
    Key: { settingId: "payment", scope: "global" }
  }));
  const gateway = ((_b = ps.Item) == null ? void 0 : _b.activeGateway) || "stripe";
  return { invoice, gateway };
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
