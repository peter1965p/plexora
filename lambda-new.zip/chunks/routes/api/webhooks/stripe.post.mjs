import { d as defineEventHandler, e as readRawBody, b as getHeader, c as createError, u as useRuntimeConfig } from '../../../nitro/nitro.mjs';
import Stripe from 'stripe';
import { GetCommand, UpdateCommand, PutCommand } from '@aws-sdk/lib-dynamodb';
import { SESClient, SendRawEmailCommand } from '@aws-sdk/client-ses';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const stripe_post = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const config = useRuntimeConfig();
  const stripe = new Stripe(config.stripeSecretKey);
  const dynamo = getDynamoClient();
  const ses = new SESClient({ region: "eu-central-1" });
  const rawBody = await readRawBody(event);
  const sig = getHeader(event, "stripe-signature") || "";
  let webhookSecret = process.env.NUXT_STRIPE_WEBHOOK_SECRET || "";
  try {
    const ps = await dynamo.send(new GetCommand({
      TableName: "plexora-settings",
      Key: { settingId: "payment", scope: "global" }
    }));
    if ((_a = ps.Item) == null ? void 0 : _a.stripeWebhookSecret) webhookSecret = ps.Item.stripeWebhookSecret;
  } catch {
  }
  let stripeEvent;
  try {
    stripeEvent = stripe.webhooks.constructEvent(rawBody, sig, webhookSecret);
  } catch (err) {
    console.error("Webhook Signatur ung\xFCltig:", err.message);
    throw createError({ statusCode: 400, message: `Webhook Error: ${err.message}` });
  }
  if (stripeEvent.type === "checkout.session.completed") {
    const session = stripeEvent.data.object;
    const metadata = session.metadata || {};
    if (metadata.invoiceId && metadata.userId) {
      await dynamo.send(new UpdateCommand({
        TableName: "plexora-finance",
        Key: { userId: metadata.userId, invoiceId: metadata.invoiceId },
        UpdateExpression: "SET #st = :st, paidAt = :p, stripeSessionId = :sid",
        ExpressionAttributeNames: { "#st": "status" },
        ExpressionAttributeValues: {
          ":st": "paid",
          ":p": (/* @__PURE__ */ new Date()).toISOString(),
          ":sid": session.id
        }
      }));
      console.log(`\u2705 Rechnung ${metadata.invoiceId} als bezahlt markiert`);
    }
    if (metadata.type === "shop_purchase") {
      const customerEmail = ((_b = session.customer_details) == null ? void 0 : _b.email) || "";
      const customerName = ((_c = session.customer_details) == null ? void 0 : _c.name) || "Kunde";
      const productName = metadata.productName || "Plexora";
      const tenantId = randomUUID();
      await dynamo.send(new PutCommand({
        TableName: "plexora-tenants",
        Item: {
          tenantId,
          email: customerEmail,
          name: customerName,
          productId: metadata.productId || "",
          productName,
          stripeSession: session.id,
          status: "active",
          created: (/* @__PURE__ */ new Date()).toISOString()
        }
      }));
      if (metadata.productId) {
        try {
          await dynamo.send(new UpdateCommand({
            TableName: "plexora-products",
            Key: { userId: metadata.productUserId || "demo-user", productId: metadata.productId },
            UpdateExpression: "SET stock = stock - :one",
            ExpressionAttributeValues: { ":one": 1 }
          }));
        } catch {
        }
      }
      if (customerEmail) {
        const subject = `Willkommen bei Plexora \u2014 ${productName}`;
        const rawEmail = [
          `From: Plexora <billing@paeffgen-it.de>`,
          `To: ${customerEmail}`,
          `Subject: ${subject}`,
          `MIME-Version: 1.0`,
          `Content-Type: text/html; charset=UTF-8`,
          ``,
          `<html><body style="font-family:sans-serif;color:#333;max-width:600px;margin:0 auto">`,
          `<h1 style="color:#7C3AED">Willkommen bei Plexora! \u{1F389}</h1>`,
          `<p>Hallo ${customerName},</p>`,
          `<p>vielen Dank f\xFCr deinen Kauf von <strong>${productName}</strong>!</p>`,
          `<p>Dein Zugang wird in K\xFCrze eingerichtet. Du erh\xE4ltst eine weitere E-Mail mit deinen Login-Daten.</p>`,
          `<div style="margin:32px 0;text-align:center">`,
          `<a href="https://plexora.paeffgen-it.de" style="background:#7C3AED;color:#fff;padding:14px 32px;border-radius:8px;text-decoration:none;font-weight:bold">Zu Plexora</a>`,
          `</div>`,
          `<p style="color:#999;font-size:12px">Das Plexora Team</p>`,
          `</body></html>`
        ].join("\r\n");
        try {
          await ses.send(new SendRawEmailCommand({ RawMessage: { Data: Buffer.from(rawEmail) } }));
          console.log(`\u2705 Welcome Mail an ${customerEmail}`);
        } catch (err) {
          console.error("Welcome Mail fehlgeschlagen:", err);
        }
      }
      console.log(`\u2705 Shop-Kauf: Tenant ${tenantId} f\xFCr ${customerEmail}`);
    }
  }
  return { received: true };
});

export { stripe_post as default };
//# sourceMappingURL=stripe.post.mjs.map
