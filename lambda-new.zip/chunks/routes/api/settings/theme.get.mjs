import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { GetCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const DEFAULTS = {
  theme: "dark",
  accent: "#6C3FE8",
  accentRgb: "108, 63, 232"
};
const theme_get = defineEventHandler(async () => {
  const client = getDynamoClient();
  try {
    const result = await client.send(new GetCommand({
      TableName: "plexora-settings",
      Key: { settingId: "theme", scope: "global" }
    }));
    return { theme: result.Item || DEFAULTS };
  } catch {
    return { theme: DEFAULTS };
  }
});

export { theme_get as default };
//# sourceMappingURL=theme.get.mjs.map
