import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { GetCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const payment_get = defineEventHandler(async () => {
  const client = getDynamoClient();
  try {
    const res = await client.send(new GetCommand({
      TableName: "plexora-settings",
      Key: { settingId: "payment", scope: "global" }
    }));
    return { payment: res.Item || null };
  } catch {
    return { payment: null };
  }
});

export { payment_get as default };
//# sourceMappingURL=payment.get.mjs.map
