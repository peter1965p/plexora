import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const payment_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const client = getDynamoClient();
  await client.send(new PutCommand({
    TableName: "plexora-settings",
    Item: {
      settingId: "payment",
      scope: "global",
      activeGateway: body.activeGateway || "stripe",
      // Stripe
      stripeSecretKey: body.stripeSecretKey || "",
      stripePublishableKey: body.stripePublishableKey || "",
      stripeWebhookSecret: body.stripeWebhookSecret || "",
      // PayPal
      paypalClientId: body.paypalClientId || "",
      paypalSecret: body.paypalSecret || "",
      paypalSandbox: (_a = body.paypalSandbox) != null ? _a : true,
      // Mollie
      mollieApiKey: body.mollieApiKey || "",
      // Custom
      customName: body.customName || "",
      customApiUrl: body.customApiUrl || "",
      customApiKey: body.customApiKey || "",
      updated: (/* @__PURE__ */ new Date()).toISOString()
    }
  }));
  return { success: true };
});

export { payment_post as default };
//# sourceMappingURL=payment.post.mjs.map
