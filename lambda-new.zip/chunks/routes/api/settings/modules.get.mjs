import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { GetCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const modules_get = defineEventHandler(async () => {
  var _a;
  const client = getDynamoClient();
  const res = await client.send(new GetCommand({
    TableName: "plexora-settings",
    Key: { settingId: "modules", scope: "global" }
  }));
  return { modules: ((_a = res.Item) == null ? void 0 : _a.modules) || null };
});

export { modules_get as default };
//# sourceMappingURL=modules.get.mjs.map
