import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const session_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const client = getDynamoClient();
  await client.send(new PutCommand({
    TableName: "plexora-settings",
    Item: {
      settingId: "session",
      scope: "global",
      timeoutMinutes: typeof body.timeoutMinutes === "number" ? body.timeoutMinutes : 5,
      updated: (/* @__PURE__ */ new Date()).toISOString()
    }
  }));
  return { success: true };
});

export { session_post as default };
//# sourceMappingURL=session.post.mjs.map
