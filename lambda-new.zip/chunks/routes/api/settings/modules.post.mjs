import { d as defineEventHandler, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const modules_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const client = getDynamoClient();
  if (!body.modules) throw createError({ statusCode: 400, statusMessage: "modules erforderlich" });
  await client.send(new PutCommand({
    TableName: "plexora-settings",
    Item: {
      settingId: "modules",
      scope: "global",
      modules: JSON.stringify(body.modules),
      updated: (/* @__PURE__ */ new Date()).toISOString()
    }
  }));
  return { success: true };
});

export { modules_post as default };
//# sourceMappingURL=modules.post.mjs.map
