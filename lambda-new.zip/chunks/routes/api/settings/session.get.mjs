import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { GetCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const DEFAULTS = { timeoutMinutes: 5 };
const session_get = defineEventHandler(async () => {
  const client = getDynamoClient();
  try {
    const result = await client.send(new GetCommand({
      TableName: "plexora-settings",
      Key: { settingId: "session", scope: "global" }
    }));
    return { session: result.Item || DEFAULTS };
  } catch {
    return { session: DEFAULTS };
  }
});

export { session_get as default };
//# sourceMappingURL=session.get.mjs.map
