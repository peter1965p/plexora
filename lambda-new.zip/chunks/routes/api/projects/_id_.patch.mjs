import { d as defineEventHandler, a as getRouterParam, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { ScanCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const _id__patch = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const projectId = getRouterParam(event, "id");
  const body = await readBody(event);
  const client = getDynamoClient();
  const scan = await client.send(new ScanCommand({
    TableName: "plexora-projects",
    FilterExpression: "projectId = :id",
    ExpressionAttributeValues: { ":id": projectId }
  }));
  const existing = (_a = scan.Items) == null ? void 0 : _a[0];
  if (!existing) throw createError({ statusCode: 404, message: "Projekt nicht gefunden" });
  await client.send(new UpdateCommand({
    TableName: "plexora-projects",
    Key: { userId: existing.userId, projectId },
    UpdateExpression: "SET #nm = :nm, description = :desc, companyId = :coid, contactId = :ctid, team = :tm, deadline = :dl, progress = :pg, #st = :st, priority = :pr, notes = :no",
    ExpressionAttributeNames: { "#nm": "name", "#st": "status" },
    ExpressionAttributeValues: {
      ":nm": body.name,
      ":desc": body.description || "",
      ":coid": body.companyId || "",
      ":ctid": body.contactId || "",
      ":tm": body.team || "",
      ":dl": body.deadline || "",
      ":pg": (_c = (_b = body.progress) != null ? _b : existing.progress) != null ? _c : 0,
      ":st": body.status || "active",
      ":pr": body.priority || "medium",
      ":no": body.notes || ""
    }
  }));
  return { success: true };
});

export { _id__patch as default };
//# sourceMappingURL=_id_.patch.mjs.map
