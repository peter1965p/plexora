import { d as defineEventHandler, r as readBody } from '../../nitro/nitro.mjs';
import { PutCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../_/dynamodb.mjs';
import { randomUUID } from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const client = getDynamoClient();
  const campaign = {
    userId: body.userId || "demo-user",
    campaignId: randomUUID(),
    name: body.name || "",
    slug: body.slug || "",
    formId: body.formId || "",
    headline: body.headline || "",
    subtext: body.subtext || "",
    headerImageUrl: body.headerImageUrl || "",
    accentColor: body.accentColor || "#6C3FE8",
    utmSource: body.utmSource || "",
    utmMedium: body.utmMedium || "",
    utmCampaign: body.utmCampaign || "",
    active: true,
    created: (/* @__PURE__ */ new Date()).toISOString()
  };
  await client.send(new PutCommand({ TableName: "plexora-marketing", Item: campaign }));
  return { success: true, campaign };
});

export { index_post as default };
//# sourceMappingURL=index.post8.mjs.map
