import { d as defineEventHandler, a as getRouterParam, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { ScanCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { g as getDynamoClient } from '../../../_/dynamodb.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@aws-sdk/client-dynamodb';

const _id__patch = defineEventHandler(async (event) => {
  var _a;
  const contractId = getRouterParam(event, "id");
  const body = await readBody(event);
  const client = getDynamoClient();
  const scan = await client.send(new ScanCommand({
    TableName: "plexora-contracts",
    FilterExpression: "contractId = :id",
    ExpressionAttributeValues: { ":id": contractId }
  }));
  const existing = (_a = scan.Items) == null ? void 0 : _a[0];
  if (!existing) throw createError({ statusCode: 404, message: "Vertrag nicht gefunden" });
  await client.send(new UpdateCommand({
    TableName: "plexora-contracts",
    Key: { userId: existing.userId, contractId },
    UpdateExpression: "SET title = :ti, contractNumber = :cn, #ty = :ty, companyId = :coi, contactId = :cti, startDate = :sd, endDate = :ed, #val = :val, billingCycle = :bc, autoRenew = :ar, noticePeriodDays = :np, #st = :st, notes = :no",
    ExpressionAttributeNames: { "#ty": "type", "#val": "value", "#st": "status" },
    ExpressionAttributeValues: {
      ":ti": body.title,
      ":cn": body.contractNumber || "",
      ":ty": body.type || "service",
      ":coi": body.companyId || "",
      ":cti": body.contactId || "",
      ":sd": body.startDate || "",
      ":ed": body.endDate || "",
      ":val": body.value || "",
      ":bc": body.billingCycle || "monthly",
      ":ar": !!body.autoRenew,
      ":np": body.noticePeriodDays || 0,
      ":st": body.status || "active",
      ":no": body.notes || ""
    }
  }));
  return { success: true };
});

export { _id__patch as default };
//# sourceMappingURL=_id_.patch.mjs.map
